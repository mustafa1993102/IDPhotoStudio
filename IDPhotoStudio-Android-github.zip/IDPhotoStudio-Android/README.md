# استوديو الصور الرسمية · ID Photo Studio

تطبيق أندرويد لتجهيز الصور الشخصية للمعاملات الحكومية: قص بالمقاسات الرسمية أو مقاس حر، تحسين الإضاءة، خلفية بيضاء، وطباعة ورقة A4 بعدة نسخ.

An Android app (WebView + native bridge) that prepares ID/passport photos and lays them out on an A4 sheet for printing.

## الميزات
- رفع عدة صور، ولكل صورة قصها وتعديلاتها وعدد نسخها
- مقاسات جاهزة (3.5×4.5، 4×6، 3×4، 5×5 سم) ومقاس حر
- سطوع وتباين وتشبع وتكبير وتدوير
- خلفية بيضاء تلقائية للخلفيات الموحدة
- إطار حول كل صورة وخطوط قص
- طباعة مباشرة أو حفظ الورقة في المعرض بدقة 300 DPI

## البناء
**من GitHub:** ادخل تبويب Actions ثم Build APK ثم Run workflow، ونزّل ملف APK من قسم Artifacts.

**محلياً:** افتح المجلد في Android Studio ثم Run. الحد الأدنى Android 10 (API 29).

الواجهة موجودة في `app/src/main/assets/index.html`، والجسر الأصلي (طباعة، حفظ، اختيار ملفات) في `MainActivity.kt`.

## الترخيص
MIT
